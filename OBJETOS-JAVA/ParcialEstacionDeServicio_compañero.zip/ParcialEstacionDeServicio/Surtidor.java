/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialEstacionDeServicio;

/**
 *
 * @author Pablo Negrelli
 */
public class Surtidor {
    private String tipoCombustible;
    private int precioPorLitro;
    private int cantVentas=0;
    private int maxVentas;
    private Venta [] vVentas;
    
    
    public void agregarSurtidor(String com,int lit,int max){
        this.setTipoCombustible(com);
        this.setPrecioPorLitro(lit);
        this.setMaxVentas(max);
        vVentas = new Venta[max];
    }
    
    public void agregarVenta(int dni,int lit,String pago){
        if(this.getCantVentas()<this.getMaxVentas()){
            vVentas[this.getCantVentas()] = new Venta();
            vVentas[this.getCantVentas()].agregarVenta(dni,lit,this.getPrecioPorLitro(),pago);
            this.setCantVentas(this.getCantVentas()+1);
        }
        else
            System.out.println("NO SE PUEDE REALIZAR LA VENTA EN ESTE SURTIDOR");
    }
    
    public int montoTotal(){
        int aux=0;
        for(int i=0;i<this.getMaxVentas();i++)
            if(vVentas[i].getMedioDePago().equals("efectivo")&&(vVentas[i]!=null)) 
                aux+=vVentas[i].getMonto();
        return aux;
    }
    
    @Override
    public String toString(){
        String aux=this.getTipoCombustible()+", "+this.getPrecioPorLitro()+"; Ventas: ";
        for(int i=0;i<this.getCantVentas();i++)
            aux+=vVentas[i].toString();
        return aux;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public int getPrecioPorLitro() {
        return precioPorLitro;
    }

    public void setPrecioPorLitro(int precioPorLitro) {
        this.precioPorLitro = precioPorLitro;
    }

    public int getCantVentas() {
        return cantVentas;
    }

    public void setCantVentas(int cantVentas) {
        this.cantVentas = cantVentas;
    }

    public int getMaxVentas() {
        return maxVentas;
    }

    public void setMaxVentas(int maxVentas) {
        this.maxVentas = maxVentas;
    }
}
