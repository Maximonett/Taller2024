/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialEstacionDeServicio;

/**
 *
 * @author Pablo Negrelli
 */
public class Estacion {
    private String direccion;
    private int maxSurtidores=6;
    private int cantSurtidores=0;
    private Surtidor [] vSurtidores;
    
    public Estacion(String dir){
        this.setDireccion(dir);
        vSurtidores = new Surtidor[this.getMaxSurtidores()];
    }
    
    public void agregarSurtidor(String com,int lit,int max){
        vSurtidores[this.getCantSurtidores()] = new Surtidor();
        vSurtidores[this.getCantSurtidores()].agregarSurtidor(com, lit, max);
        this.setCantSurtidores(this.getCantSurtidores()+1);
    }
    
    public void agregarVenta(int n,int dni,int lit,String pago){
        vSurtidores[n-1].agregarVenta(dni, lit, pago);
    }
    
    public int surtidorQueMasRecaudo(){
        int surMax=0;
        int maxMonto=0;
        int act;
        for(int i=0;i<this.getCantSurtidores();i++){
            if(vSurtidores[i]!=null){
                act = vSurtidores[i].montoTotal();
                if(act>maxMonto){
                    maxMonto=act;
                    surMax=i;
                }
            }
        }
        return surMax;
    }
    
    @Override
    public String toString(){
        String aux="Estacion de servicio: "+this.getDireccion()+"; cantidad de surtidores: "+this.getCantSurtidores()+"\n";
        for(int i=0;i<this.getCantSurtidores();i++){
            aux+="Surtidor "+(i+1)+": "+vSurtidores[i].toString();
        }
        return aux;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getMaxSurtidores() {
        return maxSurtidores;
    }

    public void setMaxSurtidores(int maxSurtidores) {
        this.maxSurtidores = maxSurtidores;
    }

    public int getCantSurtidores() {
        return cantSurtidores;
    }

    public void setCantSurtidores(int cantSurtidores) {
        this.cantSurtidores = cantSurtidores;
    }
}
