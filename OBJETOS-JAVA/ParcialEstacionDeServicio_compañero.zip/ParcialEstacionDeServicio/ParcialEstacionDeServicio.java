/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialEstacionDeServicio;

/**
 *
 * @author Pablo Negrelli
 */
public class ParcialEstacionDeServicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estacion e = new Estacion("La Plata, 520 y 25");
        e.agregarSurtidor("super", 1050, 5);
        e.agregarSurtidor("Gasoil", 520, 3);
        e.agregarSurtidor("V-power", 1160, 10);
        e.agregarVenta(1, 11111111, 15, "efectivo");
        e.agregarVenta(2, 22222222, 10, "debito");
        e.agregarVenta(1, 33333333, 20, "efectivo");
        e.agregarVenta(3, 44444444, 40, "credito");
        e.agregarVenta(3, 55555555, 23, "efectivo");
        e.agregarVenta(3, 66666666, 16, "efectivo");
        System.out.println(e.toString());
        System.out.println(e.surtidorQueMasRecaudo());
        
    }
    
}
