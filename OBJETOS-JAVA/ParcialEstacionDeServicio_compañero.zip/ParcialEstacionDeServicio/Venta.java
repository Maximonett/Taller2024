/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialEstacionDeServicio;

/**
 *
 * @author Pablo Negrelli
 */
public class Venta {
    private int DNI_Cliente;
    private int litrosCargados;
    private int monto;
    private String medioDePago;
    
    public Venta(){
        
    }
    
    public void agregarVenta(int dni,int lit,int mon, String pago){
        this.setDNI_Cliente(dni);
        this.setLitrosCargados(lit);
        this.setMonto(mon*this.getLitrosCargados());
        this.setMedioDePago(pago);
    }
    
    @Override
    public String toString(){
        return this.getDNI_Cliente()+", "+this.getLitrosCargados()+", "+this.getMonto()+"\n";
    }

    public int getDNI_Cliente() {
        return DNI_Cliente;
    }

    public void setDNI_Cliente(int DNI_Cliente) {
        this.DNI_Cliente = DNI_Cliente;
    }

    public int getLitrosCargados() {
        return litrosCargados;
    }

    public void setLitrosCargados(int litrosCargados) {
        this.litrosCargados = litrosCargados;
    }

    public int getMonto() {
        return monto;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }

    public String getMedioDePago() {
        return medioDePago;
    }

    public void setMedioDePago(String medioDePago) {
        this.medioDePago = medioDePago;
    }
}
